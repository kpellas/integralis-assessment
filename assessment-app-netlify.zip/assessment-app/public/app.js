// Assessment Application Logic

// State management
const state = {
    currentQuestion: 0,
    answers: {},
    questions: [],
    contactInfo: {}
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
    await loadQuestions();
    setupEventListeners();
});

// Load questions from config
async function loadQuestions() {
    try {
        const response = await fetch('/config/questions.json');
        const data = await response.json();
        state.questions = data.questions;
        renderQuestions();
    } catch (error) {
        console.error('Error loading questions:', error);
        alert('Failed to load assessment questions. Please refresh the page.');
    }
}

// Render all questions in the DOM (hidden initially)
function renderQuestions() {
    const container = document.getElementById('question-container');
    container.innerHTML = '';

    state.questions.forEach((q, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'question';
        questionDiv.id = `question-${index}`;
        if (index === 0) questionDiv.classList.add('active');

        questionDiv.innerHTML = `
            <span class="pillar-label">${q.pillar}</span>
            <h3>Question ${index + 1}</h3>
            <p class="question-text">${q.text}</p>
            <div class="answer-options">
                ${renderAnswerOptions(q.id, q.scale)}
            </div>
        `;

        container.appendChild(questionDiv);
    });

    updateProgress();
    updateTotalQuestions();
}

// Render answer options for a question
function renderAnswerOptions(questionId, scale) {
    return scale.map((option, index) => `
        <label class="answer-option" data-question="${questionId}" data-value="${index}">
            <input type="radio" name="q${questionId}" value="${index}" ${state.answers[questionId] === index ? 'checked' : ''}>
            <div class="answer-label">
                <strong>${option.label}</strong>
                <small>${option.description}</small>
            </div>
        </label>
    `).join('');
}

// Setup event listeners
function setupEventListeners() {
    // Start button
    document.getElementById('start-btn').addEventListener('click', () => {
        showPage('assessment-page');
    });

    // Answer selection
    document.getElementById('question-container').addEventListener('click', (e) => {
        const option = e.target.closest('.answer-option');
        if (option) {
            const questionId = parseInt(option.dataset.question);
            const value = parseInt(option.dataset.value);
            
            // Update state
            state.answers[questionId] = value;
            
            // Update UI
            const allOptions = document.querySelectorAll(`[data-question="${questionId}"]`);
            allOptions.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
            
            // Enable next button
            document.getElementById('next-btn').disabled = false;
        }
    });

    // Navigation buttons
    document.getElementById('prev-btn').addEventListener('click', () => {
        if (state.currentQuestion > 0) {
            state.currentQuestion--;
            showQuestion(state.currentQuestion);
        }
    });

    document.getElementById('next-btn').addEventListener('click', () => {
        if (!state.answers.hasOwnProperty(state.questions[state.currentQuestion].id)) {
            alert('Please select an answer before continuing.');
            return;
        }

        if (state.currentQuestion < state.questions.length - 1) {
            state.currentQuestion++;
            showQuestion(state.currentQuestion);
        } else {
            // Assessment complete, show contact form
            showPage('contact-page');
        }
    });

    // Contact form submission
    document.getElementById('contact-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const name = document.getElementById('contact-name').value.trim();
        const email = document.getElementById('contact-email').value.trim();
        const organisation = document.getElementById('organisation-name').value.trim();

        // Validate corporate email
        if (!email.match(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)) {
            alert('Please enter a valid corporate email address.');
            return;
        }

        // Store contact info
        state.contactInfo = { name, email, organisation };

        // Submit assessment
        await submitAssessment();
    });
}

// Show specific page
function showPage(pageId) {
    const pages = ['landing-page', 'assessment-page', 'contact-page', 'results-page'];
    pages.forEach(page => {
        document.getElementById(page).style.display = page === pageId ? 'block' : 'none';
    });
}

// Show specific question
function showQuestion(index) {
    const questions = document.querySelectorAll('.question');
    questions.forEach((q, i) => {
        q.classList.toggle('active', i === index);
    });

    // Update navigation buttons
    document.getElementById('prev-btn').disabled = index === 0;
    document.getElementById('next-btn').disabled = !state.answers.hasOwnProperty(state.questions[index].id);
    
    // Update button text
    const nextBtn = document.getElementById('next-btn');
    nextBtn.textContent = index === state.questions.length - 1 ? 'Complete Assessment' : 'Next';

    updateProgress();
}

// Update progress bar
function updateProgress() {
    const progress = ((state.currentQuestion + 1) / state.questions.length) * 100;
    document.getElementById('progress-fill').style.width = `${progress}%`;
    document.getElementById('current-question').textContent = state.currentQuestion + 1;
}

// Update total questions display
function updateTotalQuestions() {
    document.getElementById('total-questions').textContent = state.questions.length;
}

// Submit assessment to backend
async function submitAssessment() {
    // Show loading overlay
    document.getElementById('loading-overlay').style.display = 'flex';

    try {
        const payload = {
            organisation: state.contactInfo.organisation,
            contactName: state.contactInfo.name,
            contactEmail: state.contactInfo.email,
            answers: state.answers,
            submittedAt: new Date().toISOString()
        };

        const response = await fetch('/.netlify/functions/generateReport', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`Server error: ${response.status}`);
        }

        const result = await response.json();

        // Hide loading overlay
        document.getElementById('loading-overlay').style.display = 'none';

        // Show results page
        displayResults(result);
        showPage('results-page');

    } catch (error) {
        console.error('Error submitting assessment:', error);
        document.getElementById('loading-overlay').style.display = 'none';
        alert('There was an error generating your report. Please try again or contact support@integralis.com.au');
    }
}

// Display results summary
function displayResults(result) {
    const summaryDiv = document.getElementById('results-summary');
    
    summaryDiv.innerHTML = `
        <div class="overall-score">
            <div class="score-value">${result.overallScore}%</div>
            <div class="score-label">${result.overallLevel}</div>
        </div>
        
        <h3>Your Capability Scores</h3>
        <div class="pillar-scores">
            ${result.pillarScores.map(pillar => `
                <div class="pillar-score">
                    <span class="pillar-name">${pillar.name}</span>
                    <span class="pillar-value">${pillar.score}%</span>
                </div>
            `).join('')}
        </div>
    `;
}
