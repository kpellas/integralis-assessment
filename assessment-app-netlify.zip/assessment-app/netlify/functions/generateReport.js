const chromium = require('chrome-aws-lambda');
const puppeteer = require('puppeteer-core');
const sgMail = require('@sendgrid/mail');
const fs = require('fs').promises;
const path = require('path');

// Initialize SendGrid
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

exports.handler = async (event) => {
    // Only accept POST requests
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

    try {
        // Parse request body
        const data = JSON.parse(event.body);
        const { organisation, contactName, contactEmail, answers } = data;

        // Validate required fields
        if (!organisation || !contactName || !contactEmail || !answers) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing required fields' })
            };
        }

        // Load configuration files
        const [pillars, questions, narratives, frameworks] = await Promise.all([
            loadConfig('pillars.json'),
            loadConfig('questions.json'),
            loadConfig('overall_level_narratives.json'),
            loadConfig('framework_guidance.json')
        ]);

        // Calculate scores
        const scores = calculateScores(answers, questions, pillars);
        
        // Determine maturity level
        const overallLevel = determineMaturityLevel(scores.overall, narratives);
        
        // Identify strengths and gaps
        const insights = identifyInsights(answers, questions, pillars);
        
        // Determine framework recommendations
        const recommendedFrameworks = determineFrameworks(scores, frameworks);
        
        // Generate HTML report
        const reportHtml = generateReportHtml({
            organisation,
            contactName,
            date: new Date().toLocaleDateString('en-AU', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            }),
            scores,
            overallLevel,
            insights,
            recommendedFrameworks,
            pillars,
            narratives
        });

        // Generate PDF
        const pdfBuffer = await generatePdf(reportHtml);

        // Send email
        await sendEmail(contactEmail, contactName, organisation, pdfBuffer);

        // Return success response with summary
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: true,
                overallScore: scores.overall,
                overallLevel: overallLevel.label,
                pillarScores: scores.pillars.map(p => ({
                    name: p.name,
                    score: p.score
                }))
            })
        };

    } catch (error) {
        console.error('Error processing assessment:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ 
                error: 'Failed to process assessment',
                details: error.message 
            })
        };
    }
};

// Load configuration file
async function loadConfig(filename) {
    const filePath = path.join(__dirname, '../../src/config', filename);
    const content = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(content);
}

// Calculate all scores
function calculateScores(answers, questionsConfig, pillarsConfig) {
    const questionsList = questionsConfig.questions;
    const pillarsList = pillarsConfig.pillars;
    
    // Group questions by pillar
    const pillarQuestions = {};
    pillarsList.forEach(pillar => {
        pillarQuestions[pillar.id] = questionsList.filter(q => q.pillar === pillar.name);
    });
    
    // Calculate pillar scores
    const pillarScores = pillarsList.map(pillar => {
        const questions = pillarQuestions[pillar.id];
        const totalPossible = questions.length * 5; // Max score per question is 5
        const actualScore = questions.reduce((sum, q) => {
            return sum + (answers[q.id] || 0);
        }, 0);
        
        return {
            id: pillar.id,
            name: pillar.name,
            score: Math.round((actualScore / totalPossible) * 100)
        };
    });
    
    // Calculate overall score (average of all pillar scores)
    const overallScore = Math.round(
        pillarScores.reduce((sum, p) => sum + p.score, 0) / pillarScores.length
    );
    
    return {
        overall: overallScore,
        pillars: pillarScores
    };
}

// Determine maturity level from overall score
function determineMaturityLevel(score, narratives) {
    if (score <= 30) return narratives.levels.find(l => l.threshold === 30);
    if (score <= 60) return narratives.levels.find(l => l.threshold === 60);
    if (score <= 80) return narratives.levels.find(l => l.threshold === 80);
    return narratives.levels.find(l => l.threshold === 100);
}

// Identify top strengths and gaps
function identifyInsights(answers, questionsConfig, pillarsConfig) {
    const questionsList = questionsConfig.questions;
    
    // Identify strengths (scores 4-5)
    const strengths = questionsList
        .filter(q => answers[q.id] >= 4)
        .map(q => ({ question: q, score: answers[q.id] }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 3);
    
    // Identify gaps (scores 0-2)
    const gaps = questionsList
        .filter(q => answers[q.id] <= 2)
        .map(q => ({ question: q, score: answers[q.id] }))
        .sort((a, b) => a.score - b.score)
        .slice(0, 3);
    
    return { strengths, gaps };
}

// Determine recommended frameworks
function determineFrameworks(scores, frameworksConfig) {
    const recommendations = [];
    
    frameworksConfig.frameworks.forEach(framework => {
        let shouldRecommend = false;
        
        // Check if framework conditions are met
        if (framework.conditions) {
            shouldRecommend = framework.conditions.every(condition => {
                const pillar = scores.pillars.find(p => p.id === condition.pillar);
                if (!pillar) return false;
                
                if (condition.operator === 'gte') return pillar.score >= condition.threshold;
                if (condition.operator === 'lte') return pillar.score <= condition.threshold;
                if (condition.operator === 'gt') return pillar.score > condition.threshold;
                if (condition.operator === 'lt') return pillar.score < condition.threshold;
                
                return false;
            });
        }
        
        if (shouldRecommend) {
            recommendations.push(framework);
        }
    });
    
    return recommendations;
}

// Generate PDF from HTML
async function generatePdf(html) {
    let browser = null;
    
    try {
        browser = await puppeteer.launch({
            args: chromium.args,
            defaultViewport: chromium.defaultViewport,
            executablePath: await chromium.executablePath,
            headless: chromium.headless
        });
        
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });
        
        const pdf = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: {
                top: '20mm',
                right: '15mm',
                bottom: '20mm',
                left: '15mm'
            }
        });
        
        return pdf;
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

// Generate report HTML
function generateReportHtml(data) {
    const { organisation, contactName, date, scores, overallLevel, insights, recommendedFrameworks, pillars, narratives } = data;
    
    return `
<!DOCTYPE html>
<html lang="en-AU">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Capability Assessment Report - ${organisation}</title>
    <style>
        @page {
            margin: 20mm 15mm;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            line-height: 1.6;
            color: #212529;
        }
        .cover {
            text-align: center;
            padding: 60px 20px;
            page-break-after: always;
        }
        .cover h1 {
            color: #2B4F72;
            font-size: 36px;
            margin-bottom: 20px;
        }
        .cover .org-name {
            font-size: 28px;
            color: #6c757d;
            margin-bottom: 40px;
        }
        .cover .score-circle {
            display: inline-block;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(135deg, #2B4F72, #4a7ba7);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 40px 0;
        }
        .cover .score-value {
            font-size: 72px;
            font-weight: bold;
        }
        .cover .score-label {
            font-size: 20px;
            margin-top: 10px;
        }
        .cover .date {
            color: #6c757d;
            margin-top: 40px;
        }
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        h2 {
            color: #2B4F72;
            font-size: 24px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 3px solid #2B4F72;
        }
        h3 {
            color: #2B4F72;
            font-size: 18px;
            margin: 20px 0 10px 0;
        }
        .pillar-score {
            background: #E8EEF3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            page-break-inside: avoid;
        }
        .pillar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .pillar-name {
            font-size: 18px;
            font-weight: bold;
            color: #2B4F72;
        }
        .pillar-percentage {
            font-size: 24px;
            font-weight: bold;
            color: #2B4F72;
        }
        .strength-item, .gap-item {
            padding: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #28a745;
            background: #f8f9fa;
        }
        .gap-item {
            border-left-color: #dc3545;
        }
        .framework-box {
            background: #E8EEF3;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            page-break-inside: avoid;
        }
        .framework-title {
            font-weight: bold;
            color: #2B4F72;
            margin-bottom: 5px;
        }
        ul {
            margin-left: 20px;
            margin-top: 10px;
        }
        li {
            margin-bottom: 8px;
        }
        .footer {
            text-align: center;
            padding: 20px;
            color: #6c757d;
            font-size: 12px;
            margin-top: 40px;
            border-top: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <!-- Cover Page -->
    <div class="cover">
        <h1>IT & Cyber Capability Assessment</h1>
        <div class="org-name">${organisation}</div>
        <div class="score-circle">
            <div class="score-value">${scores.overall}%</div>
            <div class="score-label">${overallLevel.label}</div>
        </div>
        <div class="date">Prepared for: ${contactName}<br>${date}</div>
    </div>

    <!-- Executive Summary -->
    <div class="section">
        <h2>Executive Summary</h2>
        <p>${overallLevel.narrative}</p>
    </div>

    <!-- Pillar Scores -->
    <div class="section">
        <h2>Capability Assessment by Pillar</h2>
        ${scores.pillars.map(pillar => {
            const pillarConfig = pillars.pillars.find(p => p.id === pillar.id);
            return `
                <div class="pillar-score">
                    <div class="pillar-header">
                        <div class="pillar-name">${pillar.name}</div>
                        <div class="pillar-percentage">${pillar.score}%</div>
                    </div>
                    <p>${pillarConfig.description}</p>
                </div>
            `;
        }).join('')}
    </div>

    <!-- Strengths -->
    ${insights.strengths.length > 0 ? `
    <div class="section">
        <h2>Key Strengths</h2>
        ${insights.strengths.map(item => `
            <div class="strength-item">
                <strong>${item.question.pillar}</strong><br>
                ${item.question.text}
            </div>
        `).join('')}
    </div>
    ` : ''}

    <!-- Gaps -->
    ${insights.gaps.length > 0 ? `
    <div class="section">
        <h2>Priority Improvement Areas</h2>
        ${insights.gaps.map(item => `
            <div class="gap-item">
                <strong>${item.question.pillar}</strong><br>
                ${item.question.text}
            </div>
        `).join('')}
    </div>
    ` : ''}

    <!-- Framework Recommendations -->
    ${recommendedFrameworks.length > 0 ? `
    <div class="section">
        <h2>Recommended Frameworks</h2>
        ${recommendedFrameworks.map(framework => `
            <div class="framework-box">
                <div class="framework-title">${framework.name}</div>
                <p>${framework.description}</p>
            </div>
        `).join('')}
    </div>
    ` : ''}

    <!-- Next Steps -->
    <div class="section">
        <h2>Next Steps</h2>
        <p>Based on your assessment results, we recommend:</p>
        <ul>
            <li>Review the priority improvement areas identified in this report</li>
            <li>Consider the recommended frameworks for your maturity level</li>
            <li>Schedule a consultation with Integralis to discuss a tailored roadmap</li>
        </ul>
    </div>

    <div class="footer">
        <strong>Integralis</strong><br>
        www.integralis.com.au<br>
        This report is confidential and prepared specifically for ${organisation}
    </div>
</body>
</html>
    `;
}

// Send email with PDF attachment
async function sendEmail(toEmail, toName, organisation, pdfBuffer) {
    const msg = {
        to: toEmail,
        from: {
            email: process.env.FROM_EMAIL || 'assessment@integralis.com.au',
            name: process.env.FROM_NAME || 'Integralis Assessment Team'
        },
        subject: `Your IT Capability Assessment Results - ${organisation}`,
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2B4F72;">Thank you for completing your assessment</h2>
                <p>Hi ${toName},</p>
                <p>Thank you for completing the IT & Cyber Capability Assessment for ${organisation}.</p>
                <p>Your personalised report is attached to this email as a PDF. This report includes:</p>
                <ul>
                    <li>Your overall capability maturity score</li>
                    <li>Detailed scores across all five capability pillars</li>
                    <li>Identified strengths and priority improvement areas</li>
                    <li>Framework recommendations tailored to your maturity level</li>
                </ul>
                <p>If you'd like to discuss your results or explore how Integralis can help improve your IT capabilities, please don't hesitate to reach out.</p>
                <p>Best regards,<br>
                <strong>The Integralis Team</strong></p>
                <hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;">
                <p style="font-size: 12px; color: #6c757d;">
                    Integralis<br>
                    <a href="https://integralis.com.au">www.integralis.com.au</a>
                </p>
            </div>
        `,
        attachments: [
            {
                content: pdfBuffer.toString('base64'),
                filename: `${organisation.replace(/[^a-z0-9]/gi, '-')}-Capability-Assessment.pdf`,
                type: 'application/pdf',
                disposition: 'attachment'
            }
        ]
    };

    await sgMail.send(msg);
}
